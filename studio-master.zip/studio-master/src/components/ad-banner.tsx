import { Rocket } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";

export function AdBanner() {
  return (
    <Card className="bg-secondary/30 border-dashed border-primary/50 my-8">
      <CardContent className="p-4 min-h-[120px] flex items-center justify-center">
        {/* 
          광고를 여기에 추가하세요! 
          
          이곳은 광고를 표시하기 위한 자리입니다.
          구글 애드센스나 쿠팡 파트너스에서 받은 광고 코드를 아래에 붙여넣으세요.
          
          예시 (실제 코드로 교체해야 합니다):
          <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
               crossOrigin="anonymous"></script>
          <ins className="adsbygoogle"
               style={{ display: 'block' }}
               data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
               data-ad-slot="XXXXXXXXXX"
               data-ad-format="auto"
               data-full-width-responsive="true"></ins>
          <script>
               (adsbygoogle = window.adsbygoogle || []).push({});
          </script>
        */}

        {/* --- 광고 코드를 아래에 붙여넣으세요 --- */}

        <div className="text-center text-muted-foreground">
          <Rocket className="w-8 h-8 mb-2 mx-auto text-primary" />
          <p className="font-semibold text-primary">광고 표시 영역</p>
          <p className="text-sm">이곳에 광고 코드를 삽입하면 광고가 표시됩니다.</p>
        </div>
        
        {/* --- 여기까지 --- */}
      </CardContent>
    </Card>
  );
}
