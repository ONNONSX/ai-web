
"use client";

import {
  Smile,
  Hand,
  BrainCircuit,
  Users,
  Ticket,
  Palette,
  Heart,
} from "lucide-react";
import ServiceCard from "@/components/service-card";
import { useTranslation } from "@/components/language-provider";
import { AdBanner } from "@/components/ad-banner";

export default function Home() {
  const { t } = useTranslation();

  const services = [
    {
      title: t('services.face_reading.title'),
      description: t('services.face_reading.description'),
      href: "/face-reading",
      icon: Smile,
      image: "https://placehold.co/600x400.png",
      imageHint: "face physiognomy"
    },
    {
      title: t('services.palm_reading.title'),
      description: t('services.palm_reading.description'),
      href: "/palm-reading",
      icon: Hand,
      image: "https://placehold.co/600x400.png",
      imageHint: "palm lines"
    },
    {
      title: t('services.dream_interpretation.title'),
      description: t('services.dream_interpretation.description'),
      href: "/dream-interpretation",
      icon: BrainCircuit,
      image: "https://placehold.co/600x400.png",
      imageHint: "surreal dream"
    },
    {
      title: t('services.personality_test.title'),
      description: t('services.personality_test.description'),
      href: "/personality-test",
      icon: Users,
      image: "https://placehold.co/600x400.png",
      imageHint: "personality psychology"
    },
    {
      title: t('services.lotto_analysis.title'),
      description: t('services.lotto_analysis.description'),
      href: "/lotto-analysis",
      icon: Ticket,
      image: "https://placehold.co/600x400.png",
      imageHint: "lottery balls"
    },
    {
      title: t('services.personal_color_test.title'),
      description: t('services.personal_color_test.description'),
      href: "/personal-color-test",
      icon: Palette,
      image: "https://placehold.co/600x400.png",
      imageHint: "color palette"
    },
  ];

  return (
    <main className="flex-1 overflow-y-auto p-4 md:p-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-headline tracking-tight">
          {t('home_page.title')}
        </h1>
        <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          {t('home_page.subtitle')}
        </p>
      </div>

      <AdBanner />

      <div className="grid gap-6 md:gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {services.map((service) => (
          <ServiceCard key={service.href} {...service} />
        ))}
      </div>
    </main>
  );
}
